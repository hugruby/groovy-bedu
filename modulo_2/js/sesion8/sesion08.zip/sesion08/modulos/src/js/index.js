import {sum, multiply} from "./helpers"

console.log(sum(2,3))
console.log(multiply(4,3))
console.log("hola javascript")