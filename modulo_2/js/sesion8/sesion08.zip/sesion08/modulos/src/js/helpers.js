
const sum = (a,b) => a+b
const multiply = (a,b) => a*b

export { sum, multiply }